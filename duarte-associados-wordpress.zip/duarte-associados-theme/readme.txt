DUARTE & ASSOCIADOS – TEMA WORDPRESS
Versão: 1.0.0

INSTALAÇÃO
1. No painel WordPress, acesse Aparência > Temas > Adicionar novo > Enviar tema.
2. Envie duarte-associados-wordpress.zip e clique em Instalar e Ativar.
3. Acesse Aparência > Personalizar > Duarte & Associados – Dados institucionais.
4. Atualize WhatsApp, nome profissional, OAB, localidade e e-mail.
5. Em Configurações > Geral, ajuste o título do site para “Duarte & Associados”.
6. Em Aparência > Menus, crie o menu principal com links #areas, #sobre e #contato e atribua-o a Menu principal.

IMPORTANTE
- Os dados de advogada/OAB precisam ser confirmados antes da publicação. O WhatsApp começa vazio e o botão permanece inativo até a configuração.
- O tema não configura domínio, hospedagem, SSL, e-mail ou plugins de terceiros.
- Revise o conteúdo e a publicidade profissional conforme as regras vigentes da OAB antes de publicar.
