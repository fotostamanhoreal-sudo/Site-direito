<?php get_header(); ?>
<main id="conteudo" class="da-container" style="padding-block:40px">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<article <?php post_class(); ?>><h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1><?php the_excerpt(); ?></article>
<?php endwhile; the_posts_navigation(); else : ?><h1><?php esc_html_e( 'Conteúdo não encontrado.', 'duarte-associados' ); ?></h1><?php endif; ?>
</main>
<?php get_footer(); ?>
