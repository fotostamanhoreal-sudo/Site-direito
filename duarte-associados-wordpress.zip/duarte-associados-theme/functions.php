<?php
/** Theme setup and assets. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function da_theme_setup() {
    load_theme_textdomain( 'duarte-associados', get_template_directory() . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'align-wide' );
    register_nav_menus( array( 'primary' => __( 'Menu principal', 'duarte-associados' ) ) );
}
add_action( 'after_setup_theme', 'da_theme_setup' );
function da_enqueue_assets() {
    wp_enqueue_style( 'da-google-fonts', 'https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Newsreader&display=swap', array(), null );
    wp_enqueue_style( 'da-theme-style', get_stylesheet_uri(), array( 'da-google-fonts' ), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'da_enqueue_assets' );
function da_customize_register( $wp_customize ) {
    $wp_customize->add_section( 'da_contact', array( 'title' => __( 'Duarte & Associados – Dados institucionais', 'duarte-associados' ), 'priority' => 35 ) );
    $fields = array(
        'da_whatsapp' => array( 'WhatsApp com DDI e DDD (somente números)', '' ),
        'da_lawyer_name' => array( 'Nome da advogada / advogado', 'Dra. Helena Duarte' ),
        'da_oab' => array( 'Inscrição OAB', 'OAB/MG a confirmar' ),
        'da_city' => array( 'Localidade de atendimento', 'Belo Horizonte e região metropolitana' ),
        'da_email' => array( 'E-mail profissional (opcional)', '' ),
    );
    foreach ( $fields as $key => $field ) {
        $wp_customize->add_setting( $key, array( 'default' => $field[1], 'sanitize_callback' => $key === 'da_email' ? 'sanitize_email' : 'sanitize_text_field' ) );
        $wp_customize->add_control( $key, array( 'label' => $field[0], 'section' => 'da_contact', 'type' => 'text' ) );
    }
}
add_action( 'customize_register', 'da_customize_register' );
function da_whatsapp_url() {
    $number = preg_replace( '/\D+/', '', get_theme_mod( 'da_whatsapp', '' ) );
    return $number ? 'https://wa.me/' . $number : '';
}
