<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#conteudo"><?php esc_html_e( 'Pular para o conteúdo', 'duarte-associados' ); ?></a>
<header class="da-header">
  <div class="da-container">
    <nav class="da-nav" aria-label="<?php esc_attr_e( 'Navegação principal', 'duarte-associados' ); ?>">
      <a class="da-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( get_bloginfo( 'name' ) ?: 'Duarte & Associados' ); ?></a>
      <?php if ( has_nav_menu( 'primary' ) ) : ?>
        <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'da-menu', 'fallback_cb' => false ) ); ?>
      <?php else : ?>
        <ul class="da-menu"><li><a href="#areas">Áreas</a></li><li><a href="#sobre">Sobre</a></li><li><a href="#contato">Contato</a></li></ul>
      <?php endif; ?>
    </nav>
  </div>
</header>
