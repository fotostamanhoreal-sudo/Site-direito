<footer class="da-footer">
  <p><?php echo esc_html( get_bloginfo( 'name' ) ?: 'Duarte & Associados' ); ?> · <?php echo esc_html( get_theme_mod( 'da_oab', 'OAB/MG a confirmar' ) ); ?> · Conteúdo informativo. Publicidade profissional sujeita às normas da OAB.</p>
  <?php wp_footer(); ?>
</footer>
</body></html>
