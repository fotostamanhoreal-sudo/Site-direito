<?php get_header(); ?>
<main id="conteudo">
<section class="da-header">
 <div class="da-container da-hero">
  <div>
   <p class="da-motto">Suum cuique tribuere — dar a cada um o que é seu</p>
   <h1>Cuidado jurídico para as decisões mais importantes da sua família</h1>
   <p>Atendimento em divórcio, guarda, pensão alimentícia, inventário e planejamento sucessório.</p>
   <?php if ( da_whatsapp_url() ) : ?><a class="da-button" href="<?php echo esc_url( da_whatsapp_url() ); ?>" target="_blank" rel="noopener noreferrer">FALAR NO WHATSAPP</a><?php else : ?><span class="da-button" aria-label="WhatsApp ainda não configurado">WHATSAPP A CONFIGURAR</span><?php endif; ?>
  </div>
  <svg class="da-temple" viewBox="0 0 240 200" fill="currentColor" role="img" aria-label="Pórtico clássico">
   <path d="M20 60 120 10l100 50z"/><rect x="20" y="64" width="200" height="10"/><rect x="32" y="78" width="32" height="6"/><rect x="36" y="84" width="24" height="80" opacity=".75"/><rect x="32" y="164" width="32" height="6"/><rect x="80" y="78" width="32" height="6"/><rect x="84" y="84" width="24" height="80" opacity=".75"/><rect x="80" y="164" width="32" height="6"/><rect x="128" y="78" width="32" height="6"/><rect x="132" y="84" width="24" height="80" opacity=".75"/><rect x="128" y="164" width="32" height="6"/><rect x="176" y="78" width="32" height="6"/><rect x="180" y="84" width="24" height="80" opacity=".75"/><rect x="176" y="164" width="32" height="6"/><rect x="12" y="176" width="216" height="8"/><rect x="4" y="186" width="232" height="8"/>
  </svg>
 </div>
</section>
<div class="da-frieze" aria-hidden="true"></div>
<section class="da-container" id="areas" aria-label="Áreas de atuação">
 <div class="da-areas">
  <article class="da-area"><h2>Direito de Família</h2><p>Divórcio, guarda, convivência e pensão alimentícia.</p></article>
  <article class="da-area"><h2>Sucessões</h2><p>Inventário, testamento e planejamento patrimonial.</p></article>
  <article class="da-area"><h2>Direito Civil</h2><p>Contratos, responsabilidade civil e questões imobiliárias.</p></article>
 </div>
</section>
<section class="da-about" id="sobre"><div class="da-container">
 <h2><?php echo esc_html( get_theme_mod( 'da_lawyer_name', 'Dra. Helena Duarte' ) ); ?></h2>
 <p><?php echo esc_html( get_theme_mod( 'da_oab', 'OAB/MG a confirmar' ) ); ?> · Atendimento em <?php echo esc_html( get_theme_mod( 'da_city', 'Belo Horizonte e região metropolitana' ) ); ?>.</p>
 <p>Atuação com ética, sigilo profissional e linguagem clara em todas as etapas do atendimento.</p>
</div></section>
<section class="da-contact" id="contato"><div class="da-container">
 <h2>Agende uma conversa</h2><p>Entre em contato para verificar como podemos orientar os próximos passos.</p>
 <?php if ( da_whatsapp_url() ) : ?><a class="da-button" href="<?php echo esc_url( da_whatsapp_url() ); ?>" target="_blank" rel="noopener noreferrer">CHAMAR NO WHATSAPP</a><?php else : ?><span class="da-button" aria-label="WhatsApp ainda não configurado">WHATSAPP A CONFIGURAR</span><?php endif; ?>
</div></section>
</main>
<?php get_footer(); ?>
